rename the directory _AutoLoadInitFileDialog to AutoLoadInitFileDialog
to activate this example script.
